pub trait Foo {
    type Bar;
}
pub trait ObjectQuery {
    fn query(&self);
}

use crate::prelude::internal::*;

pub trait TextureDim { }

hi::denmark! { Const<1> as TextureDim }
hi::denmark! { Const<2> as TextureDim }
hi::denmark! { Const<3> as TextureDim }

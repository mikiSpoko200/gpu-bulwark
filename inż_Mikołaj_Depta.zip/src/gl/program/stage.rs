use crate::gl::target;

pub trait Compatible { }

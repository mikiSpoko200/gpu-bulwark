
pub trait Qualifier { }

pub trait Variable {
    const BINDING: usize;
}

pub trait Location {
    const LOCATION: usize;
}



use crate::prelude::internal::*;

use super::target;
use crate::gl;
use crate::glsl;

pub mod descriptor {
    
    trait TypeDescriptor { }

    enum B { }
}